package com.zzx.ooo.cloud_eureka_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * EurekaServer
 * 
 * 
 * 主要负责微服务架构中的服务治理
 * 
 * 服务治理最主要有两个功能：服务注册、服务发现；
 * 各个微服务启动时，会通过Eureka Client向Eureka Server进行注册自己的信息，比如提供的服务，ip, 端口以及一些附加信息等；
 * Eureka Server会存储该服务的信息；SpringCloud的其他模块可以通过Eureka Server 来发现系统中的微服务并加以调用;
 * @author zxzheng
 */
@EnableEurekaServer
@SpringBootApplication
public class CloudEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudEurekaServerApplication.class, args);
	}

}
