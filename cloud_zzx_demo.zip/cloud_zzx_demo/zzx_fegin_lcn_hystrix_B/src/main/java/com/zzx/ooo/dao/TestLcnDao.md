package com.zzx.ooo.dao;

import com.tk.mapper.MyMapper;
import com.zzx.ooo.entity.Qqq;

public interface TestLcnDao extends MyMapper<Qqq> {

}
