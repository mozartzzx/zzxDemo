package com.zzx.ooo.zzxb.service;

public interface DemoService {
	/**
	 * 测试fegin的简单的
	 * @return
	 */
	String dctest();
	/**
	 * 测试fegin的简单的带参数的
	 * @return
	 */
	String paramtest(String param);
	/**
	 * 测试fegin的lcn
	 * @return
	 */
	String lcnrpc(String jsonstr,String exfalg);

}
