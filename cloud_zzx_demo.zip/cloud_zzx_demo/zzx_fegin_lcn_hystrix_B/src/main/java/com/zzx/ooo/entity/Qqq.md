package com.zzx.ooo.entity;

import javax.persistence.*;

@Table(name = "q_qq")
public class Qqq {
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "C_CODE")
    private String ccode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCcode() {
		return ccode;
	}

	public void setCcode(String ccode) {
		this.ccode = ccode;
	}

  
    
}