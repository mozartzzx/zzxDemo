package com.zzx.example;

import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

/**
 * bolt处理数据
 * @author zxzheng
 */
@SuppressWarnings("serial")
public class SplitSentenceBolt extends BaseRichBolt{
	private static final long serialVersionUID = 1L;
	private OutputCollector collector;
	/**
	 * 初始化
	 * 也会有个OutputCollector
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void prepare(Map conf, TopologyContext context, OutputCollector collector) {
		this.collector = collector;
	}

	/**
	 * 每来一个Tuple
	 *  就会运行一次
	 */
	@Override
	public void execute(Tuple tuple) {
		/**
		 * 直接根据定义的field获取
		 */
		String sentence = tuple.getStringByField("sentence");
		/**
		 * 简单处理一下不必太追究
		 */
		String[] arr=sentence.split(" ");		
		for(String word:arr){
			collector.emit(new Values(word));
		}
	}

	
	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("word"));		
	}

}
