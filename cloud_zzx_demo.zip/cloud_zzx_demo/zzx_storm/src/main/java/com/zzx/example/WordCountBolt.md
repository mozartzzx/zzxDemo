package com.zzx.example;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

public class WordCountBolt extends BaseRichBolt{

	private static final long serialVersionUID = 1L;
	private OutputCollector collector;
	private HashMap<String, Integer> hashMap = new HashMap<String, Integer> ();
	@Override
	public void prepare(Map conf, TopologyContext context, OutputCollector collector) {
		this.collector =collector;
	}
	
	@Override
	public void execute(Tuple tuple) {
		String word = tuple.getStringByField("word");
		Integer count = hashMap.get(word);
		if(count==null){
			count=0;
		}
		count++;
		hashMap.put(word, count);
		collector.emit(new Values(word,count));
	}

	

	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declare(new Fields("word","count"));	
	}

}
