package com.zzx.example;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import org.apache.storm.utils.Utils;

public class Main {
	/**
	 * 将 Spout 和 Bolt 一起绑定 构建 Topology
	 * @param args
	 */
	public static void main(String[] args) {
		TopologyBuilder builder = new 	TopologyBuilder();
		/**
		 * 设置spout
		 * 最后的3，是指定这个spout有多少个executor
		 * setNumTasks是设置有多少个task，不设置的或默认一个executor一个task
		 */
		builder.setSpout("RandomSentence", new RandomSentenceSpout(), 3).setNumTasks(1);

		builder.setBolt("SplitSentence", new SplitSentenceBolt(), 3).setNumTasks(5)
			.shuffleGrouping("RandomSentence");
		
		builder.setBolt("WordCount", new WordCountBolt(), 5).setNumTasks(10)
		.fieldsGrouping("SplitSentence",new Fields("word"));
		
		builder.setBolt("WordReport", new ReportBolt(), 5).setNumTasks(10)
		.shuffleGrouping("WordCount");
		
		Config config = new Config();
		if(args!=null&&args.length>0){
			/**
			 * 设置Workers
			 */
			config.setNumWorkers(3);
			StormSubmitter sbmitter = new StormSubmitter();
			try {
				sbmitter.submitTopology(args[0], config, builder.createTopology());
			} catch (Exception e) {
				
				e.printStackTrace();
			} 			
		}else{
			/**
			 * 在本地eclipse跑
			 */
			config.setMaxTaskParallelism(30);
			LocalCluster LocalCluster = new LocalCluster();
			LocalCluster.submitTopology("Zzxtopology", config, builder.createTopology());
			Utils.sleep(6000);
			LocalCluster.shutdown();
		}
	}

}
