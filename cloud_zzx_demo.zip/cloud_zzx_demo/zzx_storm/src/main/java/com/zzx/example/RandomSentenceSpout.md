package com.zzx.example;

import java.util.Map;
import java.util.Random;

import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.apache.storm.utils.Utils;

/**
 * Spout
 * 	  作为数据源，从外部获取数据
 *   为后面的bolt提供数据来源
 * @author zxzheng
 */
public class RandomSentenceSpout extends BaseRichSpout {
	private static final long serialVersionUID = 1L;
	/**
	 * 初始化用的，可以在里面初始化一些比如数据库连接源。消息队列等等
	 * 还有一个重要的东西就是SpoutOutputCollector 收集器，用来emit发射出数据
	 */
	private  SpoutOutputCollector collector;
	private  Random random = new Random();
	@Override
	public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		this.collector = collector;
		
	}
	/**
	 * 这个方法：
	 * 	在excutor生成的task中，会一直循环执行spout的nextTuple
	 *  在里面生成tuple,然后通过收集器发射出去，形成stream
	 */
	@Override
	public void nextTuple() {
		/**
		 * 暂时使用自己造的数据
		 */
		
	    Utils.sleep(100);
	    
	    String[] sentences = new String[]{ "a", "b",
	        "c", "d", "e" };
	   
	    String sentence = sentences[random.nextInt(sentences.length)];
	    System.out.println("发射："+sentence);
	    
	    /**
	     * 然后呢收集发射
	     * 通过new Values构建tuple
	     */
	    collector.emit(new Values(sentence));
	}

	
	/**
	 * 声明数据的feild
	 */
	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		
		declarer.declare(new Fields("sentence"));
	}

}
