package com.zzx.ooo.entity;

import javax.persistence.*;

@Table(name = "o_oo")
public class Ooo {
    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "C_STORE")
    private String cstore;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCstore() {
		return cstore;
	}

	public void setCstore(String cstore) {
		this.cstore = cstore;
	}
  
    
}