package com.zzx.ooo.zzxb.service.impl;

import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zzx.ooo.dao.TestLcnDao;
import com.zzx.ooo.entity.Ooo;
import com.zzx.ooo.fegin.client.FeginLcnBClient;
import com.zzx.ooo.fegin.client.FeginLcnCClient;
import com.zzx.ooo.zzxb.service.DemoService;
@Service
public class DemoServiceImpl implements DemoService{
	@Autowired
	private  FeginLcnBClient feginLcnBClient;
	@Autowired
	private  FeginLcnCClient feginLcnCClient;
	@Resource
	private TestLcnDao testLcnDao;
	@Override
	public String dctest() {
		
		return "IS OK DE";
	}

	@Override
	public String paramtest(String param) {
		
		return param;
	}
	
	@Override
	public String lcnrpc(String jsonstr,String exfalg){
		Ooo bendi = new Ooo();
		bendi.setId(UUID.randomUUID().toString());
		bendi.setCstore("woshi LCN");
		testLcnDao.insert(bendi);				
		if("C".equals(exfalg)){
			throw new IllegalStateException("by exFlag: "+exfalg);
		}
		return  "ok-clientC";
	}

}
