package com.zzx.rabbit.directconfig;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zzx.rabbitmq.main.Main;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class)
public class ZzxTest {
	 @Autowired
	 private ZzxSender zzxSender;
	     
	 @Test
	 public void test_sender() {
		 zzxSender.sender("sender支付订单号："+System.currentTimeMillis());
	 }
	 @Test
	 public void test_zzxqueueyml() {
		 zzxSender.zzxqueueyml("zzxqueueyml支付订单号："+System.currentTimeMillis());
	 }
}
