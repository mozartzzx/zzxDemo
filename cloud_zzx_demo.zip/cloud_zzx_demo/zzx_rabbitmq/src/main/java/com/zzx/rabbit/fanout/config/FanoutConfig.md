package com.zzx.rabbit.fanout.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * Fanout Exchange模式
 * 任何发送到FanoutExchenge上的消息都会被转发到与该Exchenge绑定的（Binding）的所有Queue上；
 * Fanout交换机转发消息是最快的
 * 
 * 性能排序：fanout > direct >> topic。比例大约为11：10：6
 * @author zxzheng
 *
 */
@Configuration
public class FanoutConfig {
	/**
	 * 创建队列
	 * @return
	 */
	@Bean(name="fqueue")
	public Queue Fqueue(){
		return new Queue("zzxfqueue1");
	}
	@Bean(name="fqueue2")
	public Queue Fqueue2(){
		return new Queue("zzxfqueue2");
	}
	@Bean(name="fqueue3")
	public Queue Fqueue3(){
		return new Queue("zzxfqueue3");
	}
	/**
	 * 创建交换机
	 * @return
	 */
	@Bean
	public FanoutExchange fanoutExchange(){
		return new FanoutExchange("zzxFanoutExchange");
	}
	/**
	 * 绑定 队列Queue 和 交换机 fanoutExchange
	 * @return
	 */
	@Bean
	public Binding Mybinding(@Qualifier("fqueue")Queue queue,FanoutExchange fanoutExchange){
		return BindingBuilder.bind(queue).to(fanoutExchange);
	}
	@Bean
	public Binding Mybinding2(@Qualifier("fqueue2")Queue queue,FanoutExchange fanoutExchange){
		return BindingBuilder.bind(queue).to(fanoutExchange);
	}
	@Bean
	public Binding Mybinding3(@Qualifier("fqueue3")Queue queue,FanoutExchange fanoutExchange){
		return BindingBuilder.bind(queue).to(fanoutExchange);
	}
}
