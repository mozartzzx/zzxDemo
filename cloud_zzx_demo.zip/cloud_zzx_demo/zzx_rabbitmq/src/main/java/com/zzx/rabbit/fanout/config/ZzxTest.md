package com.zzx.rabbit.fanout.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zzx.rabbitmq.main.Main;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class)
public class ZzxTest {
	@Autowired
	 private Fsender fsender;
	     
	 @Test
	 public void test_sender() {
		 fsender.send("【sender支付订单号："+System.currentTimeMillis());
		 fsender.send("【sender支付订单号："+System.currentTimeMillis());
		 fsender.send("【sender支付订单号："+System.currentTimeMillis());
		 fsender.send("【sender支付订单号："+System.currentTimeMillis());		 
		 fsender.send("【sender支付订单号："+System.currentTimeMillis());
	 }
}
