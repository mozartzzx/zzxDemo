package com.zzx.rabbit.topicdirect.config;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zzx.rabbit.directconfig.ZzxSender;
import com.zzx.rabbitmq.main.Main;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class)
public class ZzxTest {
	 @Autowired
	 private TopicSender topicSender;
	     
	 @Test
	 public void test_sender() {
		 topicSender.send("quick.orange.rabbit","quick.orange.rabbit【sender支付订单号："+System.currentTimeMillis());
		 topicSender.send("lazy.orange.elephant","lazy.orange.elephant【sender支付订单号："+System.currentTimeMillis());
		 topicSender.send("quick.orange.fox","quick.orange.fox【sender支付订单号："+System.currentTimeMillis());
		 topicSender.send("lazy.brown.fox","lazy.brown.fox【sender支付订单号："+System.currentTimeMillis());		 
		 topicSender.send("lazy.pink.rabbit","lazy.pink.rabbit【sender支付订单号："+System.currentTimeMillis());
	 }
	 
}
