package com.zzx.rabbit.directconfig;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component

public class ZzxReceiver2 {
	@RabbitListener(queues="zzxqueue")
	public void handleMessage(String msg){
		System.out.println("111ZzxReceiver:收到"+msg);
	}
	/**
	 * 重配置文件中获取队列
	 */
	@RabbitListener(queues="${zzx.queue}")
	public void handleMessagezzx(String msg){
		System.out.println("zzx:收到"+msg);
	}
	/**
	 * 接受多个
	 * @param msg
	 */
	@RabbitListener(queues ={"zzxqueue","${zzx.queue}"})
	public void handleMessagemore(String msg){
		System.out.println("xxxxZzxReceiver:收到"+msg);
	}
}
