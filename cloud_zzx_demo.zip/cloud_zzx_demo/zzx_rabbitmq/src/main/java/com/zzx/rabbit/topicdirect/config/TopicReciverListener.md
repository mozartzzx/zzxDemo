package com.zzx.rabbit.topicdirect.config;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class TopicReciverListener {
	@RabbitListener(queues="topictmy1")
	public void  revicertopictmy1(String msg){
		
		System.out.println("revicertopictmy1接收到消息：【"+msg+"]");
	}
	@RabbitListener(queues="topictmy2")
	public void revicertopictmy2(String msg){
		
		System.out.println("revicertopictmy2接收到消息：【"+msg+"]");
	}
}
