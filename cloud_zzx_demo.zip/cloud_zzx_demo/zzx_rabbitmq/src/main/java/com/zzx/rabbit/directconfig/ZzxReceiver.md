package com.zzx.rabbit.directconfig;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@RabbitListener(queues="tttt")
public class ZzxReceiver {
	@RabbitHandler
	public void receiver(String msg){
		System.out.println("ttttZzxReceiver:收到"+msg);
	}
	
}
