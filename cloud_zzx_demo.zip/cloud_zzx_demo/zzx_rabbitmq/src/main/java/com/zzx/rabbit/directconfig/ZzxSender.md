package com.zzx.rabbit.directconfig;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ZzxSender {
	/**
	 * 重配置文件中获取
	 */
	@Value("${zzx.queue}")
	private String zzxqueueyml;
	 @Autowired
	 private AmqpTemplate rabbitTemplate;
	 
	 public void sender(String msg){
		 System.out.println("ZzxSender:发送 "+msg);
		 rabbitTemplate.convertAndSend("zzxqueue", msg);
	 }
	 public void zzxqueueyml(String msg){
		 System.out.println("zzxqueueyml:发送 "+msg);
		 rabbitTemplate.convertAndSend(zzxqueueyml, msg);
	 }	 
}
