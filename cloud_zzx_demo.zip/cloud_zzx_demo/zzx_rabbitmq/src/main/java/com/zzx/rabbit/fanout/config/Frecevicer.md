package com.zzx.rabbit.fanout.config;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class Frecevicer {
	
	@RabbitListener(queues="zzxfqueue1")
	public void  revicerfanoutmy1(String msg){		
		System.out.println("revicerfanoutmy1接收到消息：【"+msg+"]");
	}
	@RabbitListener(queues="zzxfqueue2")
	public void  revicerfanoutmy2(String msg){		
		System.out.println("revicerfanoutmy2接收到消息：【"+msg+"]");
	}
	@RabbitListener(queues="zzxfqueue3")
	public void  revicerfanoutmy3(String msg){		
		System.out.println("revicerfanoutmy3接收到消息：【"+msg+"]");
	}
	
	
}
