package com.zzx.rabbit.directconfig;

import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * DirectExchange是RabbitMQ的默认交换机，直接使用routingKey匹配队列
 * 
 * Direct：
 * 		在创建队列的时候指定一个队列的bindingkey
 * 		当生产者发送消息的时候指定对应的队列的key，交换机就会把消息发送到与key一致的bindingkey的队列中
 * 		消费者通过@RabbitListener(queues="key")监听相应的队列
 * @author zxzheng
 */
@Configuration
public class DirectConfig {
	 /**
	 * 重配置文件中获取
	 */
	 @Value("${zzx.queue}")
	 private String zzxqueueyml;
	 @Bean
	 public Queue ZzxQueue(){
		 return new Queue("zzxqueue");
	 }
	 @Bean
	 public Queue tttt(){
		 return new Queue("tttt");
	 }
	 @Bean
	 public Queue zzxqueueyml(){
		 return new Queue(zzxqueueyml);
	 }
}
