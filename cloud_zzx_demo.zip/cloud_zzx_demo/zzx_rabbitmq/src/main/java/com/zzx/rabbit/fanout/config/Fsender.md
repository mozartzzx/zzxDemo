package com.zzx.rabbit.fanout.config;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Fsender {
	@Autowired
    private AmqpTemplate rabbitTemplate;
	public void send(String msg){
		/**
		 *  第一个参数    交换机名称
		 *  第二个参数    绑定规则（）
		 *  第三个参数    发送的消息
		 */
		rabbitTemplate.convertAndSend("zzxFanoutExchange","", msg);
	}
}
