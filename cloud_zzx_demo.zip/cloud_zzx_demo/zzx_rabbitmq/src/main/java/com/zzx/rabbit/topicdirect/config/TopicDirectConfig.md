package com.zzx.rabbit.topicdirect.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * 交换机  Topic转发模式
 * topic转发信息主要是依据通配符,队列和交换机的绑定主要是依据一种模式(通配符+字符串),
 * 而当发送消息的时候,只有指定的Key和该模式相匹配的时候,消息才会被发送到该消息队列中
 * 
 * 
 * 我们需要配置队列Queue,
 * 再配置交换机(Exchange),
 * 再把队列按照相应的规则绑定到交换机上
 * 
 * @author zxzheng
 */
@Configuration
public class TopicDirectConfig {
	/**
	 * 配置queue
	*/
	@Bean(name = "topicQueue1")
	public Queue TopicQueue1(){
		return new Queue("topictmy1");
	}
	/**
	 * 配置queue
	*/
	@Bean(name = "topicQueue2")
	public Queue TopicQueue2(){
		return new Queue("topictmy2");
	}
	/**
	 * 设置Topic 交换机Exchange
	 */
	 @Bean
	 public TopicExchange TopicExchange(){
		 return new TopicExchange("topicExchange");
	 }
	 /**
	  * //*表示一个词,#表示零个或多个词
	  */
	 /**
	  * 绑定规则1
	  */
	 @Bean
	 public Binding binding1(@Qualifier("topicQueue1") Queue queue,TopicExchange topicExchange){
		 return BindingBuilder.bind(queue).to(topicExchange).with("*.orange.*");
	 }
	 /**
	  * 绑定规则2
	  */
	 @Bean
	 public Binding binding2(@Qualifier("topicQueue2") Queue queue,TopicExchange topicExchange){
		 return BindingBuilder.bind(queue).to(topicExchange).with("*.*.rabbit");
	 }
	 /**
	  * 绑定规则1
	  */
	 @Bean
	 public Binding binding3(@Qualifier("topicQueue2") Queue queue,TopicExchange topicExchange){
		 return BindingBuilder.bind(queue).to(topicExchange).with("lazy.#");
	 }

}
