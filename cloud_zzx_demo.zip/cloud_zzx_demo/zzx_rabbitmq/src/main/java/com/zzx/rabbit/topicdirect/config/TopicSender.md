package com.zzx.rabbit.topicdirect.config;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TopicSender {
	@Autowired
    private AmqpTemplate rabbitTemplate;
	public void send(String topic,String msg){
		/**
		 * 第一个参数是交换机的名字
		 * 第二个 绑定规则
		 * 第三个发送的消息
		 */
		rabbitTemplate.convertAndSend("topicExchange", topic, msg);
	}
}
