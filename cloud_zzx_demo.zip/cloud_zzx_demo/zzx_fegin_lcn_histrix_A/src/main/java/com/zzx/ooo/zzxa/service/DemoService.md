package com.zzx.ooo.zzxa.service;

public interface DemoService {
	/**
	 * 测试fegin的简单的
	 * @return
	 */
	String dctest();
	/**
	 * 测试fegin的简单的带参数的
	 * @return
	 */
	String paramtest(String param);
	/**
	 * 测试fegin的lcn
	 * @return
	 */
	String lcntest(String exfalg);

}
