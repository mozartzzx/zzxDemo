package com.zzx.ooo.dao;

import com.tk.mapper.MyMapper;
import com.zzx.ooo.entity.Zzx;

public interface TestLcnDao extends MyMapper<Zzx> {

}
